import unittest

from game.catch import check_catch
from game.fish import Fish
from game.game_engine import GameEngine, ROUND_DURATION
from game.hook import CASTING, IDLE, RETRACTING, Hook


class FakeClock:
    def __init__(self):
        self.now = 0.0

    def __call__(self):
        return self.now


class CatchDetectionTests(unittest.TestCase):
    def setUp(self):
        self.hook = Hook(x=100, surface_y=0, max_depth_y=200, width=14, height=14)

    def test_requires_horizontal_and_vertical_overlap(self):
        same_depth_but_distant = Fish(x=200, y=100, speed=0)
        self.hook.y = 100
        self.assertIsNone(check_catch(self.hook, [same_depth_but_distant]))

        same_x_but_distant = Fish(x=100, y=140, speed=0)
        self.assertIsNone(check_catch(self.hook, [same_x_but_distant]))

    def test_returns_fish_when_rectangles_overlap(self):
        self.hook.y = 100
        fish = Fish(x=110, y=100, speed=0)
        self.assertIs(check_catch(self.hook, [fish]), fish)

    def test_fish_still_wraps_at_screen_edges(self):
        fish = Fish(x=701, y=100, speed=2, width=36)
        fish.update(700)
        self.assertEqual(fish.x, -36)


class HookTests(unittest.TestCase):
    def test_cast_cannot_restart_while_in_progress(self):
        hook = Hook(x=100, surface_y=0, max_depth_y=200)
        self.assertTrue(hook.start_cast())
        hook.y = 50
        self.assertFalse(hook.start_cast())
        self.assertEqual(hook.y, 50)
        self.assertEqual(hook.state, CASTING)

    def test_hook_retracts_at_maximum_depth(self):
        hook = Hook(x=100, surface_y=0, max_depth_y=10, speed=5)
        hook.start_cast()
        hook.update()
        hook.update()
        self.assertEqual(hook.state, RETRACTING)


class GameEngineTests(unittest.TestCase):
    def setUp(self):
        self.clock = FakeClock()
        self.engine = GameEngine(clock=self.clock)

    def test_fish_types_have_distinct_speed_value_and_appearance(self):
        fish_a, fish_b = self.engine.fish_list[:2]
        self.assertNotEqual(fish_a.speed, fish_b.speed)
        self.assertNotEqual(fish_a.point_value, fish_b.point_value)
        self.assertNotEqual(fish_a.color, fish_b.color)

    def test_caught_fish_scores_only_after_returning_to_surface(self):
        for fish_template in self.engine.fish_list[:2]:
            with self.subTest(point_value=fish_template.point_value):
                engine = GameEngine(clock=self.clock)
                fish = engine.fish_list[0]
                fish.speed = fish_template.speed
                fish.point_value = fish_template.point_value
                fish.x = engine.hook.x
                fish.y = engine.hook.y + engine.hook.height / 2
                engine.fish_list = [fish]
                engine.start_cast()
                engine.update()
                self.assertIs(engine.hooked_fish, fish)
                self.assertEqual(engine.score, 0)

                while engine.hooked_fish is not None:
                    engine.update()
                self.assertEqual(engine.score, fish.point_value)
                self.assertNotIn(fish, engine.fish_list)

    def test_timer_ends_round_and_prevents_catches_and_scoring(self):
        self.engine.hook.start_cast()
        fish = self.engine.fish_list[0]
        fish.x = self.engine.hook.x
        fish.y = 300
        self.clock.now = ROUND_DURATION - 0.01
        self.engine.update()
        self.assertFalse(self.engine.game_over)
        fish.y = self.engine.hook.y
        self.clock.now = ROUND_DURATION
        self.engine.update()
        self.assertTrue(self.engine.game_over)
        self.assertEqual(self.engine.remaining_time, 0)
        self.assertFalse(self.engine.start_cast())
        self.assertIsNone(self.engine.hooked_fish)
        self.assertIn(fish, self.engine.fish_list)

        initial_score = self.engine.score
        self.clock.now += 1
        self.engine.update()
        self.assertEqual(self.engine.score, initial_score)

    def test_restart_resets_round_and_recreates_fish_once(self):
        self.engine.start_cast()
        self.engine.hooked_fish = self.engine.fish_list.pop()
        self.engine.score = 35
        self.clock.now = 12
        self.engine.restart()

        self.assertEqual(self.engine.score, 0)
        self.assertEqual(self.engine.remaining_time, ROUND_DURATION)
        self.assertEqual(self.engine.hook.state, IDLE)
        self.assertIsNone(self.engine.hooked_fish)
        self.assertEqual(len(self.engine.fish_list), 3)
        self.assertTrue(self.engine.start_cast())
        self.assertEqual(len(self.engine.fish_list), 3)


if __name__ == "__main__":
    unittest.main()
