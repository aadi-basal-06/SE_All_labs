"""GameEngine: owns the game state and runs one frame of game logic."""

import math
import time

from game.hook import Hook, IDLE, CASTING
from game.fish import Fish
from game.catch import check_catch
from game.renderer import WIDTH, SURFACE_Y, MAX_DEPTH_Y

ROUND_DURATION = 30.0


class GameEngine:
    def __init__(self, clock=time.monotonic):
        self._clock = clock
        self.hook = Hook(x=WIDTH / 2, surface_y=SURFACE_Y, max_depth_y=MAX_DEPTH_Y, speed=5)
        self.fish_list = self._create_fish()
        self.hooked_fish = None
        self.score = 0
        self._round_started_at = self._clock()
        self.remaining_time = ROUND_DURATION
        self.game_over = False

    @staticmethod
    def _create_fish():
        return [
            Fish(x=100, y=180, speed=1.5, width=36, height=18,
                 point_value=10, color=(80, 180, 220)),
            Fish(x=400, y=280, speed=-3, width=28, height=14,
                 point_value=25, color=(245, 145, 55)),
            Fish(x=250, y=380, speed=2, width=36, height=18,
                 point_value=10, color=(80, 180, 220)),
        ]

    def _update_timer(self, now):
        elapsed = now - self._round_started_at
        self.remaining_time = max(0.0, ROUND_DURATION - elapsed)
        if self.remaining_time == 0:
            self.game_over = True

    def start_cast(self):
        """Start a cast only when the round and hook are ready."""
        self._update_timer(self._clock())
        if self.game_over or self.hooked_fish is not None:
            return False
        return self.hook.start_cast()

    def restart(self):
        """Start a fresh round without adding event handlers or game loops."""
        self.hook.reset()
        self.fish_list = self._create_fish()
        self.hooked_fish = None
        self.score = 0
        self._round_started_at = self._clock()
        self.remaining_time = ROUND_DURATION
        self.game_over = False

    def update(self):
        self._update_timer(self._clock())
        if self.game_over:
            return

        self.hook.update()

        for fish in self.fish_list:
            fish.update(WIDTH)

        if self.hooked_fish is not None:
            self.hooked_fish.x = self.hook.x
            self.hooked_fish.y = self.hook.y
            if self.hook.state == IDLE:
                self.score += self.hooked_fish.point_value
                self.hooked_fish = None
        elif self.hook.state == CASTING:
            caught = check_catch(self.hook, self.fish_list)
            if caught is not None:
                self.fish_list.remove(caught)
                self.hooked_fish = caught
                self.hooked_fish.x = self.hook.x
                self.hooked_fish.y = self.hook.y
                self.hook.catch_fish()

    def draw(self, surface, font):
        from game import renderer
        draw_list = list(self.fish_list)
        if self.hooked_fish is not None:
            draw_list.append(self.hooked_fish)
        renderer.draw_scene(surface, self.hook, draw_list)
        renderer.draw_text(surface, font, f"Score: {self.score}", (10, 10))
        renderer.draw_text(
            surface, font, f"Time: {math.ceil(self.remaining_time)}", (10, 38)
        )
        renderer.draw_text(surface, font, "SPACE: Cast   R: Restart", (10, 66))
        if self.game_over:
            renderer.draw_banner(
                surface, font, f"TIME'S UP!  Final score: {self.score}"
            )
