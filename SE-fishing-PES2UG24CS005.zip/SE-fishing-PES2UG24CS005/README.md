# Fishing Lab

This project is a single-topic Fishing-lite game using **Pygame**. It
introduces students to timed casting mechanics, overlap-based catch
detection, and stateful entity variety, using a small, readable
object-oriented codebase.

---

## What's Provided

A working Fishing game with:

- A boat and hook - press **Space** to cast; the hook retracts when it
  reaches maximum depth or catches a fish
- Fish that swim back and forth across the pond at fixed depths and
  wrap around the screen edges
- Two visually distinct fish types with different movement speeds and
  point values
- A hook that catches a fish only on actual rectangle overlap - the fish rides up attached to
  the hook and is only actually caught (scored, removed from the pond)
  once the hook fully returns to the surface
- A 30-second round timer, score display, and restart control (**R**)

When the timer expires, the round ends, the final score is displayed,
and no more catches or scoring are possible.

### **Use an LLM (e.g. ChatGPT or Claude) as your debugging and pair-programming partner for this lab.**

---

## Getting Started

### Setup

1. Make sure you have Python 3.10+ installed.
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Run the game:

```bash
python main.py
```

**Controls:** **Space** casts when the hook is idle. **R** starts a
fresh round and resets the timer, score, hook, and fish.

---

## Assignment Tasks

The assignment tasks are implemented in this version:

### Task 1: Fix the catch-detection bug

> Catch detection compares the hook and fish collision rectangles.

### Task 2: Implement multiple fish types

> Slow blue fish are worth 10 points; faster orange fish are worth 25.

### Task 3: Implement player-controlled casting

> Press **Space** to cast while idle. A cast already in progress cannot
> be interrupted or restarted.

### Task 4: Implement a 30-second round timer

> The 30-second timer uses elapsed monotonic time. When it reaches zero,
> the round ends; press **R** to restart.

---

## Expected Behavior

- A fish is only caught when the hook genuinely overlaps it - not just
  when it's at a similar depth anywhere on screen.
- A caught fish visibly rides up on the hook as it retracts; the score
  only increases once it's fully back at the surface.
- Different fish types are visually distinguishable and award the
  correct point value.
- Pressing **Space** while the hook is already out should do nothing -
  it should not interrupt or
  restart the current cast.
- The round lasts exactly 30 seconds; once time runs out, no further
  catches or scoring are possible, and the final score is shown clearly.

---

## Folder Structure

```
fishing/
├── main.py
├── requirements.txt
├── game/
│   ├── game_engine.py
│   ├── hook.py
│   ├── fish.py
│   ├── catch.py
│   └── renderer.py
└── README.md
```

---

## Submission Checklist

Submission is only the following three things:

- [ ] A 10-second video of gameplay **before** your changes, showing the bug/broken behavior
- [ ] A 10-second video of gameplay **after** your changes, showing the bug fixed and the new features working
- [ ] The Chat/LLM used page link, with the complete chat history
