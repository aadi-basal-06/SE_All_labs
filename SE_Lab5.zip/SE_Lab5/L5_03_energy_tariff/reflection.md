# Reflection Questions

## 1. What is the purpose of static code analysis?

Static code analysis is the process of examining source code without executing it to identify potential issues such as bugs, security vulnerabilities, code smells, style violations, and maintainability concerns. Its purpose is to catch problems early in the development cycle, improve code quality and security, enforce coding standards, and reduce the cost of fixing defects before they reach production or testing environments.

## 2. What are the differences between Pylint, Bandit, and Flake8?

- **Pylint**: A comprehensive static analysis tool that checks for coding standards, code smells, potential bugs, unused variables/imports, and provides an overall code quality score. It focuses on maintainability, readability, and adherence to best practices.
- **Bandit**: A security-focused static analysis tool that scans Python code for common security vulnerabilities (e.g., use of `eval()`, hardcoded passwords, SQL injection risks, insecure cryptography). It assigns severity and confidence levels to identified issues.
- **Flake8**: A lightweight tool that combines PyFlakes (logical errors), pycodestyle (PEP 8 style violations), and McCabe (complexity checking). It primarily focuses on style, formatting, and simple programming errors.

## 3. What issues did you find and why did you fix them?

**Security Issues (Bandit):**
- **Use of `eval()` on user input (line 63)**: This allowed arbitrary code execution. Fixed by replacing with `ast.literal_eval()` and validating that only numeric values are accepted. This eliminates the critical security vulnerability.

**Code Quality/Functional Issues (Pylint):**
- **Mutable default argument `history=[]` (line 12)**: Shared across function calls causing state leakage. Fixed by using `history=None` and initializing inside the function.
- **Bare `except:` clause (line 44)**: Caught all exceptions including system exits. Fixed with specific exception handling `(OSError, IOError, json.JSONDecodeError)`.
- **File operations without context managers (lines 42, 48)**: Risked resource leaks. Fixed using `with` statements with explicit UTF-8 encoding.
- **Unused imports and missing docstrings**: Improved maintainability by removing unused imports and adding comprehensive docstrings.

**Style Issues (Flake8):**
- **PEP 8 violations** (missing blank lines, long lines, trailing whitespace): Fixed for better readability and consistency with Python style guidelines.

## 4. How does static analysis contribute to security, code quality, and maintainability?

- **Security**: Tools like Bandit identify dangerous patterns (e.g., code injection via `eval()`, unsafe deserialization) before deployment, preventing exploitation. Replacing `eval()` with `ast.literal_eval()` significantly hardened the application.
- **Code Quality**: Pylint catches bugs like mutable defaults, poor exception handling, and logical errors. These fixes prevent unexpected behavior and make the code more robust.
- **Maintainability**: Flake8 enforces consistent style, while docstrings, proper error handling, and resource management make code easier to read, debug, and extend. The improved structure reduces technical debt and helps future developers understand the codebase quickly.
