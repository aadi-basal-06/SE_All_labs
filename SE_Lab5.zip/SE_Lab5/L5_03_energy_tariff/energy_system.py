import json
import ast
from datetime import datetime

# Global state
meters = {}
rates = {
    'tier1': 3.5,
    'tier2': 5.0,
    'tier3': 7.5
}
SPIKE_LIMIT = 500


def record_reading(meter_id, units, history=None):
    """Record a meter reading and update accumulated consumption.

    Args:
        meter_id: The identifier for the meter.
        units: The number of units consumed in this reading.
        history: Optional list to track reading history.

    Returns:
        The updated history list.
    """
    if history is None:
        history = []
    history.append((meter_id, units, str(datetime.now())))
    meters[meter_id] = meters.get(meter_id, 0) + units
    return history


def compute_bill(meter_id, tier_rates):
    """Compute the electricity bill for a meter using tiered rates.

    Args:
        meter_id: The identifier for the meter.
        tier_rates: A list of rates for each tier [tier1, tier2, tier3].

    Returns:
        The total bill amount.
    """
    units = meters[meter_id]
    if units <= 100:
        return units * tier_rates[0]
    elif units <= 300:
        tier1 = 100 * tier_rates[0]
        tier2 = (units - 100) * tier_rates[1]
        return tier1 + tier2
    else:
        tier1 = 100 * tier_rates[0]
        tier2 = 200 * tier_rates[1]
        tier3 = (units - 300) * tier_rates[2]
        return tier1 + tier2 + tier3


def raise_rates(percent):
    """Raise all tariff rates by the given percentage.

    Args:
        percent: The percentage increase to apply.
    """
    rates['tier1'] = rates['tier1'] * (1 + percent / 100)
    rates['tier2'] = rates['tier2'] * (1 + percent / 100)
    rates['tier3'] = rates['tier3'] * (1 + percent / 100)


def flag_spikes():
    """Identify meters with consumption above the spike limit.

    Returns:
        A list of meter IDs with high consumption.
    """
    spikes = []
    for m in meters:
        if meters[m] > SPIKE_LIMIT:
            spikes.append(m)
    return spikes


def load_meter_data(file="meters.json"):
    """Load meter data from a JSON file.

    Args:
        file: The path to the JSON file to load from.
    """
    global meters
    try:
        with open(file, encoding='utf-8') as f:
            data = f.read()
        meters = json.loads(data)
    except (OSError, IOError, json.JSONDecodeError):
        meters = {}


def save_meter_data(file="meters.json"):
    """Save meter data to a JSON file.

    Args:
        file: The path to the JSON file to save to.
    """
    with open(file, "w", encoding='utf-8') as f:
        f.write(json.dumps(meters))


def main():
    """Main function to demonstrate the energy system functionality."""
    record_reading("M-01", 120)
    record_reading("M-02", 640)
    history = record_reading("M-03", -50)
    print(f"Readings stored so far: {len(history)}")
    raise_rates(10)
    rate_list = [rates['tier1'], rates['tier2'], rates['tier3']]
    print(f"Bill M-01: {compute_bill('M-01', rate_list):.2f}")
    print(f"Bill M-03: {compute_bill('M-03', rate_list):.2f}")
    print(f"Spikes: {flag_spikes()}")
    adjustment = input(
        "Extra units for M-01 as an expression (Enter for 0): "
    ) or "0"
    try:
        units_to_add = ast.literal_eval(adjustment)
        if isinstance(units_to_add, (int, float)) and units_to_add >= 0:
            record_reading("M-01", units_to_add)
        else:
            print("Invalid input. Using 0 units.")
    except (ValueError, SyntaxError):
        print("Invalid input. Using 0 units.")
    save_meter_data()
    load_meter_data()
    print(f"Bill M-01 after reload: {compute_bill('M-01', rate_list):.2f}")


main()
